//
//  ViewController.swift
//  Jsongpo04
//
//  Created by Germán Santos Jaimes on 4/30/18.
//  Copyright © 2018 iosLab. All rights reserved.
//

import UIKit
import Alamofire

class TableViewController: UITableViewController, UISearchBarDelegate {

    var tracks = [Track]()
    let searchController = UISearchController(searchResultsController: nil)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.backgroundColor = UIColor.cyan
        // Do any additional setup after loading the view, typically from a nib.
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "celda")
        
        navigationItem.searchController = searchController
        navigationItem.hidesSearchBarWhenScrolling = false
        searchController.searchBar.delegate = self
        
    }

    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        getTracks(searchText)
    }
    
    func getTracks(_ term: String){
        let url = "http://itunes.apple.com/search?term=\(term)"
        
        
        Alamofire.request(url).responseData { (dataResponse) in
            if let error = dataResponse.error{
                print("Hay un error:", error)
            }
            
            guard let data = dataResponse.data else { return }
            let testString = String(data: data, encoding: .utf8 )
            //print(testString)
            do{
               let searchResult = try JSONDecoder().decode(SearchResults.self, from: data)
                
                print("Total de resultados: ", searchResult.resultCount)
                searchResult.results.forEach({ (track) in
                    //print(track.artistName, track.collectionName)
                    self.tracks.append(Track(artistName: track.artistName, collectionName: track.collectionName))
                    self.tableView.reloadData()
                })
            }catch let errorDecoder{
                print("Hubo un error: ", errorDecoder)
            }
        }
    }
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        print("total tracks", tracks.count)
        return tracks.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "celda", for: indexPath)
        
        cell.textLabel?.text = self.tracks[indexPath.row].collectionName
        return cell
    }

}

