//
//  SearchResults.swift
//  Jsongpo04
//
//  Created by Germán Santos Jaimes on 5/2/18.
//  Copyright © 2018 iosLab. All rights reserved.
//

import Foundation

struct SearchResults: Codable{
    var resultCount: Int
    var results: [Track]
}
