//
//  File.swift
//  Covers-gpo05
//
//  Created by Germán Santos Jaimes on 4/26/18.
//  Copyright © 2018 iosLab. All rights reserved.
//

import UIKit

class CategoryViewCell : UICollectionViewCell{
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupLayout()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func setupLayout(){
        print("Cargando celda")
    }
    
    
    
}
