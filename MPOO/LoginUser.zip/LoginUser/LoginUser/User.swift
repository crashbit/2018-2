//
//  User.swift
//  LoginUser
//
//  Created by Germán Santos Jaimes on 4/4/18.
//  Copyright © 2018 iosLab. All rights reserved.
//

import Foundation

struct User{
    var firstname: String
    var lastname: String
    var username: String
    var password: String
}
