//
//  ViewController.swift
//  Json-gpo05
//
//  Created by Germán Santos Jaimes on 5/3/18.
//  Copyright © 2018 iosLab. All rights reserved.
//

import UIKit
import Alamofire

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor.cyan
        getTracks("mecano")
    }

    func getTracks(_ term: String){
        
        let url = "http://itunes.apple.com/search?term=\(term)"
        Alamofire.request(url).responseData { (dataResonse) in
            if let err = dataResonse.error{
                print("hubo un error", err)
            }
            
            guard let data = dataResonse.data else { return }
            let testString = String(data: data, encoding: .utf8)
            //print(testString)
            
            do{
               let searchResult = try JSONDecoder().decode(resultSearch.self, from: data)
                print("Los resultados son:", searchResult.resultCount)
              
                
                searchResult.results.forEach({ (track) in
                    print(track.artistName, track.collectionName)
                })
                
            }catch let errorDecode{
                print("Hubo un error:", errorDecode)
            }
        }
        
        
        
        
    }


}

