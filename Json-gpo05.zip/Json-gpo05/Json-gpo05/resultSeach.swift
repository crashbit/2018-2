//
//  resultSeach.swift
//  Json-gpo05
//
//  Created by Germán Santos Jaimes on 5/3/18.
//  Copyright © 2018 iosLab. All rights reserved.
//

import Foundation

struct resultSearch: Codable{
    var resultCount: Int
    var results: [Track]
}
